# v3 scope-free 사전 구축 결과

이 디렉터리는 60개 법령 문서를 최신 규칙으로 다시 분할·추출·정규화한 최종본만 담는다. 중간 파일, 분할 shard, LLM 오류·재시도 기록은 상위 `work/`에만 있다. 실제 RDB·AGE·OpenSearch 적재는 수행하지 않았다.

## 결과

- 문서 60개, 의미 단위 23,123개를 빠짐없이 처리했다.
- raw SVO 레코드 23,123개에 관계 29,112개가 있다.
- 엔티티 표면형 11,317개를 canonical entity 10,392개와 alias 13,894개로 정규화했다.
- raw 술어 4,013개를 기존 98개 폐쇄형 관계 타입에 전부 매핑했다.
- raw SVO 감사와 사전 감사가 모두 통과했다.
- 전체 결과를 `GraphLoadBundle`로 건식 변환해 관계 20,723개에 근거 29,112개가 누적되고 미매핑 엔티티가 0개임을 확인했다.

## 엔티티 정규화

완전히 같은 문자열만 묶는 후보 생성 후, 이름 기반 1차 정규화와 aliases·실제 원문 기반 2차 정규화를 수행했다. `config/entity_normalization_overrides.jsonl`은 사람이 확정한 소수 기준점이며 LLM 일반화 규칙보다 우선한다.

예를 들어 `감사위원회 위원`은 `감사위원`, `감사인력의 지원`은 `감사인력 지원`, `거래소의 상근 임직원`은 `거래소의 임직원`, `검증보고서`는 `검증확인서`, `결제금액`은 `결제대금`, `경고 조치`·`경고 등 적절한 조치`는 `경고`의 alias로 포함된다. `감사의 목적, 필요성`은 사전 alias로 보존하지만 raw SVO에서는 공유 수식어를 복원해 `감사의 목적`과 `감사의 필요성`으로 나눈다.

`위원회`, `회사`, `담당자`, `담당부서`, `임원`, `대표자`는 문서 scope를 만들거나 정식 명칭으로 추론하지 않는다. 같은 문자열은 문서와 관계없이 하나의 entity와 UUID를 쓴다. 단, `이 법`, `이 영`, `이 규칙`, `이 규정`은 현재 문서명으로 해소하고 global alias에는 넣지 않는다.

금액·기간·인원·급수 등 핵심 명사를 수식하는 조건과 순수 수치 endpoint는 제거했다. `퇴직 후 2년이 지나지 않은 사람`, `문책 후 2년이 지나지 않은 사람`처럼 전체 표현이 사람의 자격 상태인 경우는 합의대로 보존한다. 원문 전체와 위치는 각 raw SVO 레코드의 `context_text`, `unit_text`, `source_ref`에서 확인할 수 있다.

## 신규 문서 그래프 구축

신규 문서에서는 사전 구축의 1차·2차 정규화를 반복하지 않는다. 엔티티가 사전에 매핑되면 사전 UUID와 canonical name을 사용하고 원표현을 실행 결과 alias에 포함한다. 매핑되지 않으면 `_` 접미사 없이 원표현 그대로 안정 UUID를 만들어 적재 대상으로 사용한다. 관계는 자유 형식으로 적재하지 않고 98개 타입 중 하나에 반드시 매핑한다.

RDB에는 document·entity·relation과 메타데이터를, AGE와 OpenSearch에는 entity·relation을 저장한다. 세 저장소는 소스가 만든 동일한 소문자 하이픈 UUID 문자열을 그대로 사용해야 하며 저장소별 ID를 다시 생성하면 안 된다. AGE 속성은 `id`, `source_name`, `target_name` 중심으로 최소화한다.

API 라우터, 내부 DTO, 인증, DB 연결·upsert·outbox 구현은 이 저장소의 범위가 아니다. 내부 코드 어시스턴트는 `woori_graph.dictionary_build.DictionaryBuildPipeline`, `woori_graph.graph_build.GraphBuildPipeline`, `GraphLoadBundle`을 내부 다중 API 서버 구조에 연결한다.

## 파일

- `semantic_units.jsonl`: 원문 위치와 상위 문맥을 포함한 의미 단위
- `raw_svo.jsonl`: 조건 정제·열거 분리가 적용된 원시 SVO
- `entity_dictionary.jsonl`: `canonical_name`이 먼저 나오고 `aliases`가 뒤따르는 엔티티 사전
- `relation_dictionary.jsonl`: 기존 98개 관계 타입과 누적 aliases
- `raw_svo.audit.json`: 분할-추출 커버리지와 raw 품질 감사
- `dictionary.audit.json`: UUID·alias 충돌·전수 매핑·관계 개수 감사
- `manifest.json`: 버전, 정책, 개수, SHA-256
